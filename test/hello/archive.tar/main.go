package main

//go:embed 
var f embed.FS

func main() {

}
